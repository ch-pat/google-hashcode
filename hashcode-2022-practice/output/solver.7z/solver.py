from parse import parse_file
import os

def solve(i):
    ingredients = {}
    for customer in i:
        for ing in customer.likes:
            add_ingredient(ingredients, ing, 1)
        for ing in customer.dislikes:
            add_ingredient(ingredients, ing, -1)
    return parse_ingredients(ingredients)


def solve2(i):
    liked = {}
    disliked = {}
    all_ingredients = set([])
    result = []
    for customer in i:
        for ing in customer.likes:
            add_ingredient(liked, ing, 1)
            all_ingredients = all_ingredients.union({ing})
        for ing in customer.dislikes:
            add_ingredient(disliked, ing, 1)
            all_ingredients = all_ingredients.union({ing})
    for ing in all_ingredients:
        if ing not in disliked:
            result += [ing]
        elif ing not in liked:
            continue
        elif liked[ing] > disliked[ing] * 0.5:
            result += [ing]
    return str(len(result)) + " " + " ".join(result)

def solve3(i):
    result = []



    return str(len(result)) + " " + " ".join(result)


def add_ingredient(ingredients_dict, ingredient, score):
    if ingredient not in ingredients_dict:
        ingredients_dict[ingredient] = score
    else:
        ingredients_dict[ingredient] += score
    return ingredients_dict

def parse_ingredients(ingredients_dict):
    out = [ing for ing, score in ingredients_dict.items() if score > 0]
    return str(len(out)) + " " + " ".join(out)



if __name__ == "__main__":
    files = [x for x in os.listdir("input")]
    inputs = []

    for f in files:
        fpath = "input/" + f
        customers = parse_file(fpath)
        inputs += [customers]
        
    for i, inp in enumerate(inputs):
        sol = solve2(inp)
        with open("output/" + files[i], "w+") as f:
            f.writelines(sol)
